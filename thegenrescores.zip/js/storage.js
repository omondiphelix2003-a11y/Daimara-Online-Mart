/**
 * Unified Storage Utility for The Genre Scores
 * Handles data persistence for users, matches, news, and transactions.
 */
const Storage = {
    // Default initial data
    defaults: {
        users: [
            {
                id: 1,
                name: 'Admin',
                email: 'omondiphelix2003@gmail.com',
                password: 'admin', // You can change this
                role: 'admin'
            }
        ],
        matches: [
            {
                id: 1,
                home: 'Liverpool',
                away: 'Arsenal',
                time: '15:00',
                date: new Date().toISOString().split('T')[0],
                status: 'live', // live, upcoming, finished
                score: '2 - 1',
                image: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=600&q=80',
                isLive: true
            }
        ],
        news: [
            {
                id: 1,
                title: 'Champions League Final Preview',
                content: 'Everything you need to know about the upcoming final...',
                image: 'https://images.unsplash.com/photo-1517466787929-bc90951d0974?w=600&q=80',
                type: 'news' // news or highlight
            }
        ],
        transactions: [], // Admin saved transaction codes: { code: 'ABC123XYZ', status: 'valid' }
        league_table: [
            { pos: 1, name: 'Liverpool', logo: '', p: 28, w: 20, d: 4, l: 4, gd: 42, pts: 64 },
            { pos: 2, name: 'Arsenal', logo: '', p: 28, w: 19, d: 4, l: 5, gd: 38, pts: 61 }
        ],
        finance_data: {
            totalRevenue: 0,
            withdrawals: []
        }
    },

    init() {
        for (const key in this.defaults) {
            if (!localStorage.getItem(key)) {
                this.set(key, this.defaults[key]);
            }
        }
    },

    get(key) {
        const data = localStorage.getItem(key);
        try {
            return data ? JSON.parse(data) : null;
        } catch (e) {
            return null;
        }
    },

    set(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    },

    update(key, id, newData) {
        const list = this.get(key) || [];
        const index = list.findIndex(item => item.id === id);
        if (index !== -1) {
            list[index] = { ...list[index], ...newData };
            this.set(key, list);
            return true;
        }
        return false;
    },

    delete(key, id) {
        const list = this.get(key) || [];
        const newList = list.filter(item => item.id !== id);
        this.set(key, newList);
    }
};

// Auto-init on script load
Storage.init();